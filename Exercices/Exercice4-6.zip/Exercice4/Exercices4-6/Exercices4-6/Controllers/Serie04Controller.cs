﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Exercices4_6.Controllers
{
    public class Serie04Controller : Controller
    {
        // GET: Serie04
        public ActionResult Index()
        {
            return View();
        }
    }
}